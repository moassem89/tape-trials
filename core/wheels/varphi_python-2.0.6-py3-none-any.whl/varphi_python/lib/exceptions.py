class VarphiRuntimeError(Exception):
    pass
